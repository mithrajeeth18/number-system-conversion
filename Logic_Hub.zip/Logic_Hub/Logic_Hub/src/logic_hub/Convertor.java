package logic_hub;
import java.math.BigInteger;
public class Convertor {

 public String convertToBinary(String type, String data) {
    try {
        switch (type.toLowerCase()) {
            case "decimal":
               
                BigInteger decimalValue = new BigInteger(data);
                return decimalValue.toString(2);

            case "octal":
                
                BigInteger octalValue = new BigInteger(data, 8);
                return octalValue.toString(2);

            case "hexal":
               
                BigInteger hexadecimalValue = new BigInteger(data, 16);
                return hexadecimalValue.toString(2);
                
            case "binary":
                
                return data;
            
            case "bcd":
                String res=convertToDecimal("bcd",data);
                String f_res=convertToBinary("Decimal",res);
                return f_res;
            default:
               
                return "Unsupported type";
        }
    } catch (NumberFormatException e) {
        
        return "Invalid data";
    }
 }

public String convertToHexadecimal(String type, String data) {
    try {
        switch (type.toLowerCase()) {
            case "decimal":
                
                BigInteger decimalValue = new BigInteger(data);
                return decimalValue.toString(16);

            case "octal":
               
                BigInteger octalValue = new BigInteger(data, 8);
                return octalValue.toString(16);

            case "binary":
               
                BigInteger binaryValue = new BigInteger(data, 2);
                return binaryValue.toString(16);

            case "hexal":
                
                return data;

            default:
                
                return "Unsupported type";
        }
    } catch (NumberFormatException e) {
        
        return "Invalid data";
    }
}

public String convertToDecimal(String type, String data) {
    try {
        switch (type.toLowerCase()) {
            case "hexal":
                BigInteger hexadecimalValue = new BigInteger(data, 16);
                return hexadecimalValue.toString();

            case "octal":
                BigInteger octalValue = new BigInteger(data, 8);
                return octalValue.toString();

            case "binary":
                BigInteger binaryValue = new BigInteger(data, 2);
                return binaryValue.toString();

            case "decimal":
                return data;
            
            case "bcd":
                try {
                StringBuilder decimalResult = new StringBuilder();
                int bcdLength = data.length();

                for (int i = 0; i < bcdLength; i += 4) {
                    String bcdDigit = data.substring(i, i + 4);
                    int decimalDigit = Integer.parseInt(bcdDigit, 2);
                    decimalResult.append(decimalDigit);
                }
                return decimalResult.toString();
                } catch (NumberFormatException e) {
                    return "Invalid data";
                }

            default:
                return "Unsupported type";
        }
    } catch (NumberFormatException e) {
        return "Invalid data";
    }
}

public String convertToOctal(String type, String data) {
    try {
        switch (type.toLowerCase()) {
            case "hexadecimal":
                BigInteger hexadecimalValue = new BigInteger(data, 16);
                return hexadecimalValue.toString(8);

            case "decimal":
                BigInteger decimalValue = new BigInteger(data);
                return decimalValue.toString(8);

            case "binary":
                BigInteger binaryValue = new BigInteger(data, 2);
                return binaryValue.toString(8);

            case "octal":
                return data;
            
            default:
                return "Unsupported type";
        }
    } catch (NumberFormatException e) {
        return "Invalid data";
    }
}
/*
// Function to convert from BCD to decimal
public  String BCDtoDecimal(String data) {
    try {
        StringBuilder decimalResult = new StringBuilder();
        int bcdLength = data.length();

        for (int i = 0; i < bcdLength; i += 4) {
            String bcdDigit = data.substring(i, i + 4);
            int decimalDigit = Integer.parseInt(bcdDigit, 2);
            decimalResult.append(decimalDigit);
        }
        return decimalResult.toString();
    } catch (NumberFormatException e) {
        return "Invalid data";
    }
}

*/
public String convertToBCD(String type, String data) {
        try {
            String res, f_res;
            switch (type.toLowerCase()) {
                case "hexal":
                    res = convertToDecimal("hexal", data);
                    f_res = convertToBCD("Decimal", res);
                    return f_res;

                case "decimal":
                    BigInteger decimalValue = new BigInteger(data);
                    // Convert decimal to BCD by converting each decimal digit to 4-bit binary
                    StringBuilder decimalBCDResult = new StringBuilder();
                    String decimalString = decimalValue.toString();
                    for (int i = 0; i < decimalString.length(); i++) {
                        char decimalDigitChar = decimalString.charAt(i);
                        int decimalDigit = Character.getNumericValue(decimalDigitChar);
                        String bcdDigit = Integer.toBinaryString(decimalDigit);
                        // Ensure each BCD digit is 4 bits (pad with leading zeros if necessary)
                        while (bcdDigit.length() < 4) {
                            bcdDigit = "0" + bcdDigit;
                        }
                        decimalBCDResult.append(bcdDigit);
                    }
                    return decimalBCDResult.toString();

                case "binary":
                    res = convertToDecimal("binary", data);
                    f_res = convertToBCD("Decimal", res);
                    return f_res;

                case "octal":
                    res = convertToDecimal("octal", data);
                    f_res = convertToBCD("decimal", res);
                    return f_res;
                case "bcd":
                    // If the input type is already BCD, return it as is
                    return data;

                default:
                    return "Unsupported type";
            }
        } catch (NumberFormatException e) {
            return "Invalid data";
        }

    }

public String perform(String num1, String num2, String type, String opt) {
    String f="Decimal";
    int a,b;
    
    try {
        int result;
        
        a = Integer.parseInt(convertToDecimal(type, num1));
        b = Integer.parseInt(convertToDecimal(type, num2));
        
        switch (opt) {
            case "add (+)":
                result = a + b;
                
                break;
            case "sub (-)":
                result = a - b;
                break;
            case "mult (*)":
                result = a * b;
                break;
            case "div (÷)":
                if (b != 0) {
                    result = a / b;
                } else {
                    return "Division by zero is not allowed.";
                }
                break;
            case "pow (^)":
                result = (int) Math.pow(a, b);
                break;
            case "and (&)":
                result = a & b;
                break;
            case "or (|)":
                result = a | b;
                break;
            case "xor (^)":
                result = a ^ b;
                break;
            case "left shift (<<)":
                result = a << b;
                break;
            case "right shift (>>)":
                result = a >> b;
                break;
            default:
                return "Unsupported operation";
        }
    
    switch(type){
                
                case "Binary":
                return convertToBinary(f, result+"");
                
                
                case "Decimal":              
                return convertToDecimal(f, result+"");
                
                
                case "Octal":              
                return convertToOctal(f, result+"");
                
                
                case "Hexal":                 
                return convertToHexadecimal(f, result+"");
                
                case "BCD":
                return convertToBCD(f, result+"");
                  
                default:
                    break;
        }
        
    } catch (NumberFormatException e) {
        return "Invalid data";
    }
     return null;
}
}

/*
package convertor;

import java.math.BigDecimal;
import java.math.BigInteger;

public class Convertor {

public String convertToBinary(String type, String data) {
        try {
            BigDecimal decimalValue = new BigDecimal(data);
            if (decimalValue.compareTo(BigDecimal.ZERO) < 0) {
                decimalValue = decimalValue.negate(); // Convert negative numbers to positive
            }
            BigInteger integerPart = decimalValue.toBigInteger();
            StringBuilder binaryResult = new StringBuilder();
            
            switch (type.toLowerCase()) {
                case "decimal":
                    return integerPart.toString(2);

                case "octal":
                    return integerPart.toString(8);

                case "hexal":
                    return integerPart.toString(16);

                case "binary":
                    binaryResult.append(integerPart.toString(2));
                    // Handle fractional part if present
                    if (decimalValue.scale() > 0) {
                        binaryResult.append(".");
                        BigDecimal fractionalPart = decimalValue.remainder(BigDecimal.ONE);
                        for (int i = 0; i < 32; i++) { // Consider up to 32 fractional digits
                            fractionalPart = fractionalPart.multiply(BigDecimal.valueOf(2));
                            binaryResult.append(fractionalPart.intValue());
                            if (fractionalPart.compareTo(BigDecimal.ONE) >= 0) {
                                fractionalPart = fractionalPart.subtract(BigDecimal.ONE);
                            }
                            if (fractionalPart.compareTo(BigDecimal.ZERO) == 0) {
                                break;
                            }
                        }
                    }
                    return binaryResult.toString();

                default:
                    return "Unsupported type";
            }
        } catch (NumberFormatException e) {
            return "Invalid data";
        }
    }
 


public String convertToHexadecimal(String type, String data) {
    try {
        switch (type.toLowerCase()) {
            case "decimal":
                BigDecimal decimalValue = new BigDecimal(data);
                if (decimalValue.compareTo(BigDecimal.ZERO) < 0) {
                    decimalValue = decimalValue.negate(); // Convert negative numbers to positive
                }
                BigInteger integerPart = decimalValue.toBigInteger();
                return integerPart.toString(16);

            case "octal":
                BigDecimal octalValue = new BigDecimal(data);
                if (octalValue.compareTo(BigDecimal.ZERO) < 0) {
                    octalValue = octalValue.negate(); // Convert negative numbers to positive
                }
                BigInteger octalIntegerPart = octalValue.toBigInteger();
                return octalIntegerPart.toString(16);

            case "binary":
                // Handle negative binary numbers
                if (data.startsWith("-")) {
                    String positiveBinary = data.substring(1); // Remove the negative sign
                    BigInteger binaryIntegerPart = new BigInteger(positiveBinary, 2);
                    return "-" + binaryIntegerPart.toString(16);
                } else {
                    BigInteger binaryIntegerPart = new BigInteger(data, 2);
                    return binaryIntegerPart.toString(16);
                }

            case "hexal":
                BigInteger hexadecimalValue = new BigInteger(data, 16);
                return hexadecimalValue.toString(16);

            default:
                return "Unsupported type";
        }
    } catch (NumberFormatException e) {
        return "Invalid data";
    }
}



    public String convertToDecimal(String type, String data) {
        try {
            switch (type.toLowerCase()) {
                case "hexal":
                    BigInteger hexadecimalValue = new BigInteger(data, 16);
                    return hexadecimalValue.toString();

                case "octal":
                    BigInteger octalValue = new BigInteger(data, 8);
                    return octalValue.toString();

                case "binary":
                    // Handle floating-point binary numbers by converting to decimal correctly
                    if (data.contains(".")) {
                        String[] parts = data.split("\\.");
                        BigInteger integerPart = new BigInteger(parts[0], 2);
                        double fractionalPart = 0.0;
                        String fractionalStr = parts[1];
                        for (int i = 0; i < fractionalStr.length(); i++) {
                            char digit = fractionalStr.charAt(i);
                            if (digit == '1') {
                                fractionalPart += Math.pow(2, -(i + 1));
                            }
                        }
                        double decimalValue = integerPart.doubleValue() + fractionalPart;
                        return Double.toString(decimalValue);
                    } else {
                        BigInteger binaryValue = new BigInteger(data, 2);
                        return binaryValue.toString();
                    }

                case "decimal":
                    return data;

                default:
                    return "Unsupported type";
            }
        } catch (NumberFormatException e) {
            return "Invalid data";
        }
    }



    public String convertToOctal(String type, String data) {
    try {
        switch (type.toLowerCase()) {
            case "hexal":
                BigInteger hexadecimalValue = new BigInteger(data, 16);
                return hexadecimalValue.toString(8);

            case "decimal":
                BigDecimal decimalValue = new BigDecimal(data);
                if (decimalValue.compareTo(BigDecimal.ZERO) < 0) {
                    decimalValue = decimalValue.negate(); // Convert negative numbers to positive
                }
                BigInteger integerPart = decimalValue.toBigInteger();
                return integerPart.toString(8);

            case "binary":
                // Handle negative binary numbers
                if (data.startsWith("-")) {
                    String positiveBinary = data.substring(1); // Remove the negative sign
                    BigDecimal binaryDecimalValue = new BigDecimal(new BigInteger(positiveBinary, 2).toString());
                    return "-" + convertToOctal("decimal", binaryDecimalValue.toString());
                } else {
                    // Convert binary to octal by first converting to decimal and then to octal
                    BigDecimal binaryDecimalValue = new BigDecimal(new BigInteger(data, 2).toString());
                    return convertToOctal("decimal", binaryDecimalValue.toString());
                }

            case "octal":
                return data;

            default:
                return "Unsupported type";
        }
    } catch (NumberFormatException e) {
        return "Invalid data";
    }
}




    public String convertToBCD(String type, String data) {
        try {
            switch (type.toLowerCase()) {
                case "hexal":
                    BigInteger hexadecimalValue = new BigInteger(data, 16);
                    // Convert hexadecimal to BCD by converting each digit to 4-bit binary
                    StringBuilder bcdResult = new StringBuilder();
                    char[] hexChars = hexadecimalValue.toString(16).toCharArray();
                    for (char hexChar : hexChars) {
                        int decimalDigit = Integer.parseInt(String.valueOf(hexChar), 16);
                        String bcdDigit = Integer.toBinaryString(decimalDigit);
                        // Ensure each BCD digit is 4 bits (pad with leading zeros if necessary)
                        while (bcdDigit.length() < 4) {
                            bcdDigit = "0" + bcdDigit;
                        }
                        bcdResult.append(bcdDigit);
                    }
                    return bcdResult.toString();

                case "decimal":
                    BigDecimal decimalValue = new BigDecimal(data);
                    if (decimalValue.compareTo(BigDecimal.ZERO) < 0) {
                        decimalValue = decimalValue.negate(); // Convert negative numbers to positive
                    }
                    BigInteger integerPart = decimalValue.toBigInteger();
                    // Convert decimal to BCD by converting each decimal digit to 4-bit binary
                    StringBuilder decimalBCDResult = new StringBuilder();
                    String decimalString = integerPart.toString();
                    for (int i = 0; i < decimalString.length(); i++) {
                        char decimalDigitChar = decimalString.charAt(i);
                        int decimalDigit = Character.getNumericValue(decimalDigitChar);
                        String bcdDigit = Integer.toBinaryString(decimalDigit);
                        // Ensure each BCD digit is 4 bits (pad with leading zeros if necessary)
                        while (bcdDigit.length() < 4) {
                            bcdDigit = "0" + bcdDigit;
                        }
                        decimalBCDResult.append(bcdDigit);
                    }
                    return decimalBCDResult.toString();

                case "binary":
                    // BCD representation of a binary number is the same as the binary number itself
                    return data;

                case "octal":
                    BigDecimal octalValue = new BigDecimal(data);
                    if (octalValue.compareTo(BigDecimal.ZERO) < 0 ) {
                        octalValue = octalValue.negate(); // Convert negative numbers to positive
                    }
                    BigInteger octalIntegerPart = octalValue.toBigInteger();
                    // Convert octal to BCD by first converting to binary and then to BCD
                    String binaryValue = octalIntegerPart.toString(2);
                    return convertToBCD("binary", binaryValue);

                case "bcd":
                    // If the input type is already BCD, return it as is
                    return data;

                default:
                    return "Unsupported type";
            }
        } catch (NumberFormatException e) {
            return "Invalid data";
        }
    }
}

*/