package logic_hub;
import java.awt.Color;
import java.awt.Component;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Ibrahim
 */
public class HighlightedRowRenderer extends DefaultTableCellRenderer {
    private int rowToHighlight = -1;

    // Set the row to highlight
    public void setRowToHighlight(int row) {
        this.rowToHighlight = row;
    }

    @Override
    public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
        super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);

        if (row == rowToHighlight) {
            // Highlight the selected row with a different background color (e.g., yellow)
            setBackground(Color.YELLOW);
            setForeground(Color.BLACK);
        } else {
            // Reset the background color for non-selected rows
            setBackground(table.getBackground());
            setForeground(table.getForeground());
        }

        return this;
    }
}
