/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package logic_hub;


import java.awt.Color;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;

public class TableHighlighterUtil {
    private static HighlightedRowRenderer rowRenderer = new HighlightedRowRenderer();

    public static void setCustomRenderer(JTable table) {
        table.setDefaultRenderer(Object.class, rowRenderer);
    }

    public static void highlightRow(JTable table, int rowToHighlight) {
        rowRenderer.setRowToHighlight(rowToHighlight);
        table.repaint();
    }

    static class HighlightedRowRenderer extends DefaultTableCellRenderer {
        private int rowToHighlight = -1;

        public void setRowToHighlight(int row) {
            this.rowToHighlight = row;
        }

        @Override
        public java.awt.Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
            super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);

            if (row == rowToHighlight) {
                setBackground(Color.YELLOW);
                setForeground(Color.BLACK);
            } else {
                setBackground(table.getBackground());
                setForeground(table.getForeground());
            }

            return this;
        }
    }
}
