package logic_hub;

/**
 *
 * @author mithr
 */
public class Check_Types {
    Convertor con= new Convertor();
    

    
    public boolean isBinary(String input) {
        return input.matches("-?[01]+(\\.[01]+)?");
    }

    public boolean isDecimal(String input) {
        return input.matches("-?\\d+(\\.\\d+)?");
    }

    public boolean isHexadecimal(String input) {
        return input.matches("-?[0-9A-Fa-f]+(\\.[0-9A-Fa-f]+)?");
    }

    public boolean isOctal(String input) {
        return input.matches("-?[0-7]+(\\.[0-7]+)?");
    }

    public boolean isBCD(String input) {
        
        if (input.matches("^[01]+$") && input.length() % 4 == 0) {
            int inputLength = input.length();

            for (int i = 0; i < inputLength; i += 4) {
                String section = input.substring(i, i + 4);
                int decimalValue = Integer.parseInt(section, 2);

                if (decimalValue > 9) {
                    //System.out.println("greater than 8");
                    return false;
                }
            }

            return true;
        } else {
           // System.out.println("not Satisfy 4 or binary");
            return false;
        }
    }



    public String negateBinary(String binary) {
    StringBuilder result = new StringBuilder();
    for (char bit : binary.toCharArray()) {
        if (bit == '0') {
            result.append('1');
        } else if (bit == '1') {
            result.append('0');
        } else {
            return "Invalid input";
        }
    }
    return result.toString();
}
    
    public String rightShift(String input) {
        if (input == null || input.isEmpty()) {
            return input;
        }
        // Append '0' to the start and remove the last character
        return "0" + input.substring(0, input.length() - 1);
    }
    
    public String leftShift(String input) {
        if (input == null || input.isEmpty()) {
            return input;
        }
        // Append '0' at the end and remove the first character
        return input.substring(1) + "0";
    }

}
